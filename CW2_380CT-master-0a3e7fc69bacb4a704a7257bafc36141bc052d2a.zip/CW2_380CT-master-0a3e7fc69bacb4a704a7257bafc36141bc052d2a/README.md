Coursework 2 for 380CT 

Group Members:
    Giorgos Stylianou
    Marinos Georgiou
    Nikolaos Sofroniou

You can find the coding and the pseudocodes for all the problems for the coursework
